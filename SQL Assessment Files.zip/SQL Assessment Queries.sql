Create table data_science_team( 
EMP_ID int references emp_record(EMP_ID),
FIRST_NAME varchar(255),
LAST_NAME varchar(255),
GENDER VARCHAR(255),
ROLE varchar(255),
DEPT VARCHAR(255),
EXP int,
COUNTRY VARCHAR(255),
CONTINENT VARCHAR(255)
);


Create table emp_record( 
EMP_ID int primary key,
FIRST_NAME varchar(255),
LAST_NAME varchar(255),
GENDER VARCHAR(255),
ROLE VARCHAR(255),
DEPT VARCHAR(255),
EXP INT,
COUNTRY VARCHAR(255),
CONTINENT VARCHAR(255),
SALARY INT,
EMP_RATING INT,
MANAGER VARCHAR(255),
PROJ_ID int references proj(PROJECT_ID)
);

Create table proj( 
PROJECT_ID VARCHAR(255) primary key,
PROJ_NAME VARCHAR(255),
DOMAIN VARCHAR(255),
START_DATE int,
CLOSURE_DATE int,
DEV_QTR VARCHAR(255),
STATUS VARCHAR(255)
);


Select EMP_ID,
FIRST_NAME,
LAST_NAME,
GENDER,
DEPT
FROM 
emp_record
;


Select
    EMP_ID, 
    FIRST_NAME, 
    LAST_NAME, 
    GENDER, 
    DEPT, 
    EMP_RATING 
From 
    emp_record
Where 
    EMP_RATING < 2 
    OR EMP_RATING > 4 
    OR EMP_RATING BETWEEN 2 AND 4;



Select concat(FIRST_NAME, ' ', LAST_NAME) AS NAME
From emp_record
Where DEPT = 'FINANCE';


Select EMP_ID, FIRST_NAME, ROLE, DEPT
FROM emp_record
WHERE ROLE ='MANAGER' 
OR ROLE='PRESIDENT'
OR ROLE='CEO';



Select EMP_ID,
FIRST_NAME,
LAST_NAME,
DEPT
From emp_record 
Where DEPT = 'HEALTHCARE'

UNION ALL

Select EMP_ID,
FIRST_NAME, 
LAST_NAME,
DEPT
From emp_record 
Where DEPT = 'FINANCE';



Select 
    EMP_ID, 
    FIRST_NAME, 
    LAST_NAME, 
    ROLE, 
    DEPT, 
    EMP_RATING,
    MAX(EMP_RATING) OVER (PARTITION BY DEPT) AS MAX_DEPT_RATING
From 
    emp_record
ORDER BY 
    DEPT;



Select 
    ROLE,
    MIN(SALARY) AS MINIMUM_SALARY,
    MAX(SALARY) AS MAXIMUM_SALARY
FROM 
    emp_record
GROUP BY 
    ROLE;




Select
    EMP_ID, 
    FIRST_NAME, 
    LAST_NAME, 
    EXP,
    DENSE_RANK() OVER (ORDER BY EXP DESC) AS EXPERIENCE_RANK
FROM emp_record;





CREATE VIEW employees_in_various_countries AS
Select EMP_ID, FIRST_NAME, LAST_NAME, COUNTRY, SALARY
From emp_record
Where SALARY > 6000;




Select EMP_ID,FIRST_NAME,LAST_NAME,EXP
FROM emp_record
WHERE EMP_ID IN (
    SELECT EMP_ID
    FROM emp_record
    WHERE EXP> 10
);




Select 
    EMP_ID,
    FIRST_NAME,
    LAST_NAME,
    EXP,
    ROLE AS ASSIGNED_ROLE,
    CASE 
        WHEN EXP <= 2 THEN 'JUNIOR DATA SCIENTIST'
        WHEN EXP > 2 AND EXP <= 5 THEN 'ASSOCIATE DATA SCIENTIST'
        WHEN EXP > 5 AND EXP <= 10 THEN 'SENIOR DATA SCIENTIST'
        WHEN EXP > 10 AND EXP <= 12 THEN 'LEAD DATA SCIENTIST'
        WHEN EXP > 12 AND EXP <= 16 THEN 'MANAGER'
        ELSE 'OTHER'
    END AS STANDARD_ROLE,
    CASE 
        WHEN ROLE = (
            CASE 
                WHEN EXP <= 2 THEN 'JUNIOR DATA SCIENTIST'
                WHEN EXP > 2 AND EXP <= 5 THEN 'ASSOCIATE DATA SCIENTIST'
                WHEN EXP > 5 AND EXP <= 10 THEN 'SENIOR DATA SCIENTIST'
                WHEN EXP > 10 AND EXP <= 12 THEN 'LEAD DATA SCIENTIST'
                WHEN EXP > 12 AND EXP <= 16 THEN 'MANAGER'
                ELSE 'OTHER'
            END
        ) THEN 'MATCH'
        ELSE 'MISMATCH'
    END AS PROFILE_MATCH_STATUS
FROM data_science_team;






Select
    EMP_ID, 
    FIRST_NAME, 
    LAST_NAME, 
    SALARY, 
    EMP_RATING,
    (0.05 * SALARY * EMP_RATING) AS BONUS
From 
    emp_record;




Select 
    CONTINENT, 
    COUNTRY, 
    AVG(SALARY) AS AVERAGE_SALARY 
From 
    emp_record 
GROUP BY 
    CONTINENT, 
    COUNTRY;


